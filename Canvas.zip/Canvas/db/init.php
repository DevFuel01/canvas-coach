<?php
require_once __DIR__ . '/../config/db.php';

echo "Initializing Database...\n";

$database = new Database();
// Hack to create DB if not exists (PDO connects to DB, so we might need to connect to no DB first)
try {
    $conn = new PDO("mysql:host=localhost", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("CREATE DATABASE IF NOT EXISTS canvas_coach");
    echo "Database 'canvas_coach' created or checks out.\n";
} catch (PDOException $e) {
    die("DB Creation Failed: " . $e->getMessage());
}

// Now connect properly
$db = $database->getConnection();

$schemaFile = __DIR__ . '/schema.sql';
if (!file_exists($schemaFile)) {
    die("Schema file not found.");
}

$sql = file_get_contents($schemaFile);

try {
    $db->exec($sql);
    echo "Schema imported successfully.\n";
} catch (PDOException $e) {
    echo "Error importing schema: " . $e->getMessage() . "\n";
}
