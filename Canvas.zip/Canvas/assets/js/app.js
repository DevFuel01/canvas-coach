const App = {
    state: {
        sessionId: null,
        userToken: null,
        artworkId: null,
        lastFeedback: null
    },

    elements: {
        views: {
            setup: document.getElementById('view-setup'),
            roadmap: document.getElementById('view-roadmap'),
            coach: document.getElementById('view-coach'),
            reflection: document.getElementById('view-reflection')
        },
        setupForm: document.getElementById('setup-form'),
        // Roadmap Elements
        roadmapList: document.getElementById('roadmap-list'),
        roadmapSubject: document.getElementById('roadmap-subject'),
        btnStartDrawing: document.getElementById('btn-start-drawing'),

        uploadInput: document.getElementById('artwork-input'),
        uploadZone: document.getElementById('upload-placeholder'),
        previewContainer: document.getElementById('image-preview-container'),
        previewImage: document.getElementById('image-preview'),
        feedbackLoading: document.getElementById('feedback-loading'),
        feedbackIntro: document.getElementById('feedback-intro'),
        feedbackContent: document.getElementById('feedback-content'),
        
        // Feedback Fields
        fbSubject: document.getElementById('fb-subject'),
        fbStrengths: document.getElementById('fb-strengths'),
        fbImprovement: document.getElementById('fb-improvement'),
        lessonTitle: document.getElementById('lesson-title'),
        lessonExplanation: document.getElementById('lesson-explanation'),
        lessonApplication: document.getElementById('lesson-application'),
        btnNextStep: document.getElementById('btn-next-step'),
        nextStepReveal: document.getElementById('next-step-reveal'),
        nextStepAction: document.getElementById('next-step-action'),
        nextStepReason: document.getElementById('next-step-reason'),
        fbEncouragement: document.getElementById('fb-encouragement'),
        
        btnFinish: document.getElementById('btn-finish-session'),
        
        // Reflection
        refPrinciple: document.getElementById('ref-principle'),

        // History
        historyContainer: document.getElementById('history-container'),
        historyStrip: document.getElementById('history-strip'),
        btnCompare: document.getElementById('btn-compare'),
        compareModal: document.getElementById('compare-modal'),
        closeModal: document.querySelector('.close-modal'),
        imgFirst: document.getElementById('img-first'),
        imgLatest: document.getElementById('img-latest')
    },

    init: () => {
        console.log("App init started");
        try {
            App.bindEvents();
            App.checkResume();
            console.log("App init completed");
        } catch (e) {
            console.error("App Config Error:", e);
        }
    },

    bindEvents: () => {
        if(App.elements.setupForm) {
            console.log("Binding submit to setupForm");
            App.elements.setupForm.addEventListener('submit', App.handleSetupSubmit);
        } else {
            console.error("setupForm not found!");
        }

        if(App.elements.btnStartDrawing) {
             App.elements.btnStartDrawing.addEventListener('click', () => App.switchView('coach'));
        }

        if(App.elements.uploadInput) App.elements.uploadInput.addEventListener('change', App.handleFileUpload);
        if(App.elements.btnNextStep) App.elements.btnNextStep.addEventListener('click', App.revealNextStep);
        if(App.elements.btnFinish) App.elements.btnFinish.addEventListener('click', App.handleFinishSession);
        
        // Compare Events
        if(App.elements.btnCompare) App.elements.btnCompare.addEventListener('click', App.openCompare);
        if(App.elements.closeModal) App.elements.closeModal.addEventListener('click', () => App.elements.compareModal.classList.add('hidden'));
        window.onclick = (e) => {
            if (App.elements.compareModal && e.target == App.elements.compareModal) App.elements.compareModal.classList.add('hidden');
        };

        // Drag and drop for upload
        const zone = App.elements.uploadZone;
        if(zone) {
            zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.style.borderColor = '#8e2de2'; });
            zone.addEventListener('dragleave', (e) => { e.preventDefault(); zone.style.borderColor = 'rgba(255, 255, 255, 0.1)'; });
            zone.addEventListener('drop', (e) => {
                e.preventDefault();
                zone.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                if (e.dataTransfer.files.length) {
                    App.elements.uploadInput.files = e.dataTransfer.files;
                    App.handleFileUpload();
                }
            });
        }
        
        const reuploadBtn = document.getElementById('btn-reupload');
        if(reuploadBtn) reuploadBtn.addEventListener('click', () => {
            App.elements.uploadInput.click();
        });
    },

    checkResume: () => {
        const saved = localStorage.getItem('canvas_session');
        if (saved) {
            const session = JSON.parse(saved);
            const container = document.querySelector('.setup-card');
            const resumeBtn = document.createElement('button');
            resumeBtn.className = "btn btn-outline full-width";
            resumeBtn.innerHTML = `Resume: ${session.art_type} ${session.subject} <ion-icon name="reload-outline"></ion-icon>`;
            resumeBtn.style.marginTop = "1rem";
            resumeBtn.onclick = () => App.resumeSession(session);
            
            container.insertBefore(resumeBtn, App.elements.setupForm);
            
            const div = document.createElement('p');
            div.innerText = "— or start new —";
            div.style.margin = "1rem 0";
            div.style.color = "var(--text-secondary)";
            div.style.fontSize = "0.9rem";
            div.style.textAlign = "center";
            container.insertBefore(div, App.elements.setupForm);
        }
    },

    // ... (resumeSession existing code) ...
    resumeSession: (session) => {
        App.state.sessionId = session.id;
        App.switchView('coach');
        App.updateHistory(session.id); // Fetch history on resume
    },

    switchView: (viewName) => {
        Object.values(App.elements.views).forEach(el => el.classList.add('hidden'));
        App.elements.views[viewName].classList.remove('hidden');
        App.elements.views[viewName].classList.add('fade-in');
    },
    
    // ... (generateRoadmap existing code) ...
    generateRoadmap: (subject, artType) => {
        const templates = {
            'Portrait': [
                { title: "Composition", desc: "Draw a vertical line for the center of the face. Mark the eye line halfway down." },
                { title: "Basic Shapes", desc: "Sketch an oval for the head. Add circles for eyes and a triangle for the nose." },
                { title: "Features", desc: "Refine the eyes, nose, and mouth placement. Don't rush details yet." },
                { title: "Shading", desc: "Identify your light source. Lightly shade the side of the face away from the light." }
            ],
            'Landscape': [
                { title: "Horizon Line", desc: "Draw a horizontal line across the page. This divides sky and land." },
                { title: "Big Shapes", desc: "Block in mountains, trees, or buildings as simple shapes." },
                { title: "Depth", desc: "Things closer to you should be larger and lower on the paper." },
                { title: "Details", desc: "Add texture to trees and clouds only after the big shapes work." }
            ],
            'Still Life': [
                { title: "Placement", desc: "Imagine a box on the paper where your objects will sit." },
                { title: "Proportions", desc: "Compare the height vs width of the object. Is it tall or wide?" },
                { title: "Contour", desc: "Draw the outer edges lightly. Ignore patterns for now." },
                { title: "Value", desc: "Squint your eyes to see the darkest shadows and map them out." }
            ],
            'Abstract': [
                { title: "Feeling", desc: "Focus on the emotion you chose. What shapes represent 'Calm' or 'Energetic'?" },
                { title: "Flow", desc: "Draw lines that lead the eye across the page." },
                { title: "Balance", desc: "If you put a big shape on one side, put something small on the other." },
                { title: "Texture", desc: "Experiment with different strokes—dots, scribbles, washes." }
            ]
        };

        const steps = templates[subject] || templates['Portrait']; // Default fallback
        App.elements.roadmapSubject.innerText = `${artType} - ${subject}`;
        
        App.elements.roadmapList.innerHTML = steps.map((step, index) => `
            <div class="roadmap-item">
                <div style="background:var(--accent); width:24px; height:24px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:0.8rem;">${index+1}</div>
                <div>
                    <h4>${step.title}</h4>
                    <p>${step.desc}</p>
                </div>
            </div>
        `).join('');
    },

    updateHistory: async (sessionId) => {
        try {
            const resp = await fetch(`api/get_session_history.php?session_id=${sessionId}`);
            const data = await resp.json();
            
            if (data.artworks && data.artworks.length > 0) {
                App.elements.historyContainer.classList.remove('hidden');
                
                App.elements.historyStrip.innerHTML = data.artworks.map(art => `
                    <img src="${art.url}" class="history-thumb" onclick="App.previewImage('${art.url}')">
                `).join('');

                // Store logic for compare
                App.state.history = data.artworks;

                if (data.artworks.length >= 2) {
                    App.elements.btnCompare.classList.remove('hidden');
                }
            }
        } catch (err) {
            console.error(err);
        }
    },

    previewImage: (url) => {
        App.elements.previewImage.src = url;
    },

    openCompare: () => {
        if (!App.state.history || App.state.history.length < 2) return;
        
        const first = App.state.history[0];
        const last = App.state.history[App.state.history.length - 1];

        App.elements.imgFirst.src = first.url;
        App.elements.imgLatest.src = last.url;
        App.elements.compareModal.classList.remove('hidden');
    },

    // ... (rest of methods: switchView, handleSetupSubmit) ...

    handleFileUpload: async () => {
        const file = App.elements.uploadInput.files[0];
        if (!file) return;

        // Show Preview
        const reader = new FileReader();
        reader.onload = (e) => {
            App.elements.previewImage.src = e.target.result;
            App.elements.uploadZone.classList.add('hidden');
            App.elements.previewContainer.classList.remove('hidden');
        };
        reader.readAsDataURL(file);

        // Upload
        const formData = new FormData();
        formData.append('artwork', file);
        formData.append('session_id', App.state.sessionId);

        // UI Loading State
        App.elements.feedbackIntro.classList.add('hidden');
        App.elements.feedbackContent.classList.add('hidden');
        App.elements.feedbackLoading.classList.remove('hidden');

        try {
            const uploadResp = await fetch('api/upload_artwork.php', { method: 'POST', body: formData });
            const uploadResult = await uploadResp.json();
            if (!uploadResult.artwork_id) throw new Error(uploadResult.message || 'Upload failed');

            App.state.artworkId = uploadResult.artwork_id;
            
            // Update History
            App.updateHistory(App.state.sessionId);

            // Get feedback
            await App.getFeedback(App.state.artworkId);

        } catch (err) {
            console.error(err);
            alert('Error: ' + err.message);
            App.elements.feedbackLoading.classList.add('hidden');
        }
    },

    handleSetupSubmit: async (e) => {
        console.log("Handle Setup Submit called");
        e.preventDefault();
        const formData = new FormData(e.target);
        
        const data = {
            art_type: formData.get('art_type'),
            subject: formData.get('subject'),
            mood: formData.get('mood'),
            skill_level: formData.get('skill_level')
        };
        
        const btn = e.target.querySelector('button');
        const origText = btn.innerHTML;
        btn.innerText = "Creating Session...";
        btn.disabled = true;

        try {
            console.log("Sending fetch to api/start_session.php");
            const resp = await fetch('api/start_session.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            console.log("Response status:", resp.status);
            const result = await resp.json();
            console.log("Result:", result);
            
            if (result.session_id) {
                App.state.sessionId = result.session_id;
                
                // Save to LocalStorage
                localStorage.setItem('canvas_session', JSON.stringify({
                    id: result.session_id,
                    art_type: data.art_type,
                    subject: data.subject,
                    timestamp: new Date().toISOString()
                }));

                // Generate and Show Roadmap
                App.generateRoadmap(data.subject, data.art_type);
                App.switchView('roadmap');
            } else {
                alert('Error starting session: ' + result.message);
            }
        } catch (err) {
            console.error("Setup Submit Error:", err);
            alert('Connection error');
        } finally {
            btn.innerHTML = origText;
            btn.disabled = false;
        }
    },

    getFeedback: async (artworkId) => {
        try {
            const resp = await fetch('api/get_ai_feedback.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    session_id: App.state.sessionId,
                    artwork_id: artworkId
                })
            });

            const aiData = await resp.json();
            App.state.lastFeedback = aiData;
            App.renderFeedback(aiData);

        } catch (err) {
             console.error(err);
             alert("Error getting feedback: " + err.message);
        } finally {
             App.elements.feedbackLoading.classList.add('hidden');
        }
    },

    renderFeedback: (data) => {
        const els = App.elements;

        // Ensure clean state
        els.feedbackLoading.classList.add('hidden');
        els.feedbackIntro.classList.add('hidden');
        
        els.fbSubject.innerText = data.subject_identification || 'Artwork';
        
        // Visual Analysis
        if (data.visual_analysis) {
            document.getElementById('fb-focal-point').innerText = data.visual_analysis.focal_point || "N/A";
            document.getElementById('fb-composition').innerText = data.visual_analysis.composition || "N/A";
            document.getElementById('fb-balance').innerText = data.visual_analysis.balance_proportions || "N/A";
        }

        els.fbStrengths.innerText = data.feedback_points?.strengths || "Good effort.";
        els.fbImprovement.innerText = data.feedback_points?.improvement_opportunity || "Keep practicing.";
        
        if (data.micro_lesson) {
            els.lessonTitle.innerText = "Micro-Lesson: " + data.micro_lesson.title;
            els.lessonExplanation.innerText = data.micro_lesson.explanation;
            els.lessonApplication.innerText = data.micro_lesson.application;
        }

        if (data.next_step_action) {
            els.nextStepAction.innerText = data.next_step_action.action;
            els.nextStepReason.innerText = data.next_step_action.reason;
        } else {
             els.nextStepAction.innerText = "Continue refining your shapes.";
             els.nextStepReason.innerText = "This builds better form.";
        }

        els.fbEncouragement.innerText = data.encouragement || "Keep it up!";

        // Reset state
        els.nextStepReveal.classList.add('hidden');
        els.btnNextStep.classList.remove('hidden');

        // Show Content
        els.feedbackContent.classList.remove('hidden');
    },

    revealNextStep: () => {
        App.elements.btnNextStep.classList.add('hidden');
        App.elements.nextStepReveal.classList.remove('hidden');
        App.elements.nextStepReveal.classList.add('fade-in');
    },

    handleFinishSession: async () => {
        // Save reflection logic
        const lastData = App.state.lastFeedback;
        
        // 1. One principle practiced
        const principle = lastData?.micro_lesson?.title || "Art Fundamentals";
        
        // 2. One improvement achieved (Use 'strengths' as the win for this session)
        const improvement = lastData?.feedback_points?.strengths || "Completed a creative session";

        // 3. One practice exercise for next time
        const practice = lastData?.next_step_action?.action || "Sketch for 10 minutes daily";
        
        // Update UI
        App.elements.refPrinciple.innerText = principle;
        document.getElementById('ref-improvement').innerText = improvement;
        document.getElementById('ref-practice').innerText = practice;

        // Perform save in background
        fetch('api/save_reflection.php', {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({
                 session_id: App.state.sessionId,
                 reflection: {
                     principle: principle,
                     improvement: improvement,
                     practice: practice,
                     timestamp: new Date().toISOString()
                 }
             })
        });
        
        // Clear Local Storage
        localStorage.removeItem('canvas_session');

        App.switchView('reflection');
    }
};

document.addEventListener('DOMContentLoaded', App.init);
