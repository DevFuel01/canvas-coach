<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

setJsonHeaders();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
    exit;
}

$input = json_decode(file_get_contents("php://input"));

if (!isset($input->artwork_id) || !isset($input->session_id)) {
    http_response_code(400);
    echo json_encode(["message" => "Missing artwork_id or session_id"]);
    exit;
}

// 1. Fetch Context & Artwork Path
$database = new Database();
$db = $database->getConnection();

try {
    // Get Session Data
    $query = "SELECT * FROM sessions WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(":id", $input->session_id);
    $stmt->execute();
    $session = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$session) {
        throw new Exception("Session not found");
    }

    // Get Artwork Path
    $query = "SELECT * FROM artworks WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(":id", $input->artwork_id);
    $stmt->execute();
    $artwork = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$artwork) {
        throw new Exception("Artwork not found");
    }

    $localPath = __DIR__ . '/../' . $artwork['file_path'];
    if (!file_exists($localPath)) {
        throw new Exception("File not found on server");
    }

    // Convert image to Base64
    $imageData = base64_encode(file_get_contents($localPath));
    $mimeType = mime_content_type($localPath);

    // 2. Construct Prompt
    $promptText = "You are 'Canvas Coach', a supportive AI art mentor for beginners. 
    User Context:
    - Skill Level: {$session['skill_level']}
    - Art Type: {$session['art_type']}
    - Subject: {$session['subject']}
    - Mood: {$session['mood']}

    YOUR TASK: Analyze the uploaded artwork image and provide structured coaching feedback.
    
    STRICT RULES:
    - DO NOT generate an image.
    - DO NOT be harsh.
    - DO NOT give a score, grade, or rating (e.g., '7/10').
    - DO NOT mention specific famous artists to copy.
    - Use growth-mindset language ('Not yet', 'Improve by', 'Good start').
    - Focus on fundamentals: composition, proportions, value, line quality.
    
    REQUIRED ANALYSIS:
    1. Identify the Main Subject.
    2. Identify the Focal Point (where the eye goes first).
    3. Analyze the Composition (how elements are arranged).
    4. Analyze Balance & Proportions.

    OUTPUT JSON FORMAT:
    {
        \"subject_identification\": \"What you see in the image\",
        \"visual_analysis\": {
            \"focal_point\": \"Description of the focal point\",
            \"composition\": \"Feedback on rule of thirds, framing, or layout\",
            \"balance_proportions\": \"Feedback on visual weight and accuracy\"
        },
        \"feedback_points\": {
            \"strengths\": \"One specific thing done well (mention composition/balance if good)\",
            \"improvement_opportunity\": \"One clear thing to fix/improve\"
        },
        \"micro_lesson\": {
            \"title\": \"Name of the ONE art principle relevant here (Choose from: Rule of Thirds, Contrast, Depth, Light & Shadow, Negative Space)\",
            \"explanation\": \"Simple, beginner-friendly definition (50-80 words max). NO technical jargon without explanation.\",
            \"why_it_matters\": \"Why this helps\",
            \"application\": \"How to apply it right now to this piece\"
        },
        \"next_step_action\": {
            \"action\": \"A 5-10 min specific task\",
            \"reason\": \"Why do this next\"
        },
        \"encouragement\": \"A short motivating closing sentence\"
    }";

    // 3. Call AI API (Gemini/OpenAI structure)
    // Using a generic structure compatible with OpenAI Chat Completions or similar
    // NOTE: For Gemini API, the endpoint and structure differs slightly. 
    // Assuming standard Chat Completion format for broad compatibility or Gemini via OpenAI compat layer.
    // If using Google Gemini API directly:
    $apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=" . GEMINI_API_KEY;

    $payload = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $promptText],
                    [
                        "inline_data" => [
                            "mime_type" => $mimeType,
                            "data" => $imageData
                        ]
                    ]
                ]
            ]
        ],
        "generationConfig" => [
            "response_mime_type" => "application/json"
        ]
    ];

    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        throw new Exception("Curl error: " . curl_error($ch));
    }

    curl_close($ch);

    // 4. Parse & Save Response
    $jsonResponse = json_decode($response, true);

    // Check for API Errors
    if (isset($jsonResponse['error'])) {
        $msg = $jsonResponse['error']['message'] ?? 'Unknown AI Error';
        if ($jsonResponse['error']['code'] == 429) {
            throw new Exception("AI is currently busy (Rate Limit). Please wait 1 minute and try again.");
        }
        throw new Exception("AI Provider Error: " . $msg);
    }

    // Extract text from Gemini response structure
    if (isset($jsonResponse['candidates'][0]['content']['parts'][0]['text'])) {
        $aiContent = $jsonResponse['candidates'][0]['content']['parts'][0]['text'];

        // Clean Markdown (```json ... ```)
        $aiContent = preg_replace('/^```json\s*/', '', $aiContent);
        $aiContent = preg_replace('/^```\s*/', '', $aiContent);
        $aiContent = preg_replace('/\s*```$/', '', $aiContent);

        // Validate JSON
        $decoded = json_decode($aiContent, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Fallback JSON if AI failed format
            $aiContent = json_encode([
                "subject_identification" => "Artwork",
                "visual_analysis" => [
                    "focal_point" => "Analysis unclear",
                    "composition" => "Could not analyze",
                    "balance_proportions" => "Could not analyze"
                ],
                "feedback_points" => [
                    "strengths" => "Nice attempt.",
                    "improvement_opportunity" => "Try again clearly."
                ],
                "encouragement" => "Keep going!"
            ]);
        }

        // Save to DB
        $query = "INSERT INTO feedback (artwork_id, analysis_json) VALUES (:aid, :json)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":aid", $input->artwork_id);
        $stmt->bindParam(":json", $aiContent);
        $stmt->execute();

        echo $aiContent; // Return the raw JSON from AI
    } else {
        // Fallback or error handling
        error_log("AI RAW RESP: " . $response);
        throw new Exception("Failed to parse AI response. Response: " . substr($response, 0, 100));
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["message" => $e->getMessage()]);
}
