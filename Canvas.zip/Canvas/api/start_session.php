<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

setJsonHeaders();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->art_type) || !isset($data->subject) || !isset($data->mood)) {
    http_response_code(400);
    echo json_encode(["message" => "Incomplete data"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // 1. Create User (or reuse if we had auth, but for now anonymous session based)
    // For this MVP, we create a new user per session or could link if we had cookies.
    // simpler: Create a user record for this session.
    $token = bin2hex(random_bytes(16));

    $query = "INSERT INTO users (session_token) VALUES (:token)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(":token", $token);
    $stmt->execute();
    $userId = $db->lastInsertId();

    // 2. Create Session
    $query = "INSERT INTO sessions (user_id, art_type, subject, mood, skill_level) VALUES (:user_id, :art_type, :subject, :mood, :skill_level)";
    $stmt = $db->prepare($query);
    $skill = isset($data->skill_level) ? $data->skill_level : 'beginner';

    $stmt->bindParam(":user_id", $userId);
    $stmt->bindParam(":art_type", $data->art_type);
    $stmt->bindParam(":subject", $data->subject);
    $stmt->bindParam(":mood", $data->mood);
    $stmt->bindParam(":skill_level", $skill);

    $stmt->execute();
    $sessionId = $db->lastInsertId();

    echo json_encode([
        "message" => "Session started",
        "session_id" => $sessionId,
        "user_token" => $token
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["message" => "db error: " . $e->getMessage()]);
}
