<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

setJsonHeaders();

if (!isset($_GET['session_id'])) {
    http_response_code(400);
    echo json_encode(["message" => "Missing session_id"]);
    exit;
}

$sessionId = $_GET['session_id'];

$database = new Database();
$db = $database->getConnection();

try {
    $query = "SELECT id, file_path, upload_timestamp FROM artworks WHERE session_id = :sid ORDER BY upload_timestamp ASC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(":sid", $sessionId);
    $stmt->execute();

    $artworks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Add full URL
    foreach ($artworks as &$art) {
        $art['url'] = BASE_URL . '/' . $art['file_path'];
    }

    echo json_encode(["artworks" => $artworks]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["message" => $e->getMessage()]);
}
