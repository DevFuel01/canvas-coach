<?php
// Application Configuration

// URL Configuration
define('BASE_URL', 'http://localhost/Canvas');

// Upload Configuration
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// API Keys (Ideally loaded from env, but hardcoded for MVP as per instructions/limitations)
// REPLACE WITH YOUR GEMINI API KEY
define('GEMINI_API_KEY', 'your_actual_api_key_here');

// Error Reporting (Turn off for production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Response Headers for JSON APIs
function setJsonHeaders()
{
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF_8");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
}
