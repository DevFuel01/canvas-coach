<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Canvas Coach - AI Art Mentor</title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Outfit:wght@500;700&display=swap" rel="stylesheet">
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Ionicons for Icons -->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>

<body>

    <div class="app-background"></div>

    <header class="main-header glass-card">
        <div class="logo">
            <ion-icon name="color-palette-outline"></ion-icon>
            <span>Canvas Coach</span>
        </div>
        <nav>
            <!-- 
            <a href="#" class="nav-link">About</a>
            <a href="#" class="nav-link">Gallery</a>
            -->
        </nav>
    </header>

    <main class="container">

        <!-- View 1: Landing & Setup -->
        <section id="view-setup" class="view cancel-animation active">
            <div class="hero-text">
                <h1>Unlock Your Inner Artist.</h1>
                <p>Personalized, AI-powered coaching for beginners. No judgment, just growth.</p>
            </div>

            <div class="setup-card glass-card fade-in">
                <h2>Start Your Session</h2>
                <form id="setup-form">
                    <label for="art_type">I want to create a...</label>
                    <select id="art_type" name="art_type" required>
                        <option value="Sketch">Pencil Sketch</option>
                        <option value="Digital Drawing">Digital Drawing</option>
                        <option value="Watercolor">Watercolor Painting</option>
                        <option value="Charcoal">Charcoal Drawing</option>
                    </select>

                    <label for="subject">The subject will be...</label>
                    <select id="subject" name="subject" required>
                        <option value="Portrait">Portrait (Face/Person)</option>
                        <option value="Landscape">Landscape / Scenery</option>
                        <option value="Still Life">Still Life / Object</option>
                        <option value="Abstract">Abstract / Emotion</option>
                    </select>

                    <label for="mood">I want it to feel...</label>
                    <select id="mood" name="mood" required>
                        <option value="Calm">Calm & Peaceful</option>
                        <option value="Energetic">Energetic & Dynamic</option>
                        <option value="Melancholic">Melancholic & Moody</option>
                        <option value="Whimsical">Whimsical & Dreamy</option>
                    </select>

                    <label for="skill_level">My skill level is...</label>
                    <select id="skill_level" name="skill_level">
                        <option value="Beginner">Absolute Beginner</option>
                        <option value="Novice">I have some experience</option>
                    </select>

                    <button type="submit" class="btn btn-primary full-width">Start Coaching <ion-icon name="arrow-forward"></ion-icon></button>
                </form>
            </div>
        </section>

        <!-- View 1.5: Creation Roadmap -->
        <section id="view-roadmap" class="view hidden">
            <div class="glass-card setup-card fade-in">
                <h2>Your Creation Roadmap</h2>
                <p>Follow these steps to build your <span id="roadmap-subject" class="highlight-text">Portrait</span>.</p>

                <div class="roadmap-list" id="roadmap-list">
                    <!-- Javascript will populate this -->
                    <div class="roadmap-item">
                        <ion-icon name="radio-button-off-outline"></ion-icon>
                        <div>
                            <h4>1. Composition</h4>
                            <p>Lightly mark where the top and bottom will be.</p>
                        </div>
                    </div>
                </div>

                <button class="btn btn-primary full-width" id="btn-start-drawing">
                    I'm Ready to Start <ion-icon name="brush-outline"></ion-icon>
                </button>
            </div>
        </section>

        <!-- View 2: Coach Interface -->
        <section id="view-coach" class="view hidden">
            <div class="coach-grid">

                <!-- Left Col: Canvas/Upload -->
                <div class="artwork-area glass-card">
                    <div id="upload-placeholder" class="upload-zone">
                        <ion-icon name="cloud-upload-outline" size="large"></ion-icon>
                        <p>Upload your artwork progress</p>
                        <span class="subtext">JPG or PNG (Max 5MB)</span>
                        <input type="file" id="artwork-input" accept="image/*" hidden>
                        <button class="btn btn-outline" onclick="document.getElementById('artwork-input').click()">Choose File</button>
                    </div>
                    <div id="image-preview-container" class="hidden">
                        <img id="image-preview" src="" alt="Artwork Preview">
                        <div class="preview-actions">
                            <button class="btn btn-sm btn-glass" id="btn-reupload">New Upload</button>
                        </div>
                    </div>
                </div>

                <!-- Right Col: Feedback -->
                <div class="feedback-area glass-card">
                    <div id="feedback-loading" class="hidden">
                        <div class="spinner"></div>
                        <p>Analysing your strokes...</p>
                    </div>

                    <div id="feedback-intro" class="feedback-placeholder">
                        <h3>Waiting for artwork...</h3>
                        <p>Upload your sketch or drawing to get personalized feedback.</p>
                    </div>

                    <div id="feedback-content" class="hidden fade-in">
                        <div class="feedback-header">
                            <span class="badge" id="fb-subject">Subject</span>
                            <h3>Feedback</h3>
                        </div>

                        <!-- Analysis Validation -->
                        <div class="analysis-grid glass-card inner mb-3">
                            <div class="analysis-item">
                                <small>Focal Point</small>
                                <p id="fb-focal-point">Checking...</p>
                            </div>
                            <div class="analysis-item">
                                <small>Composition</small>
                                <p id="fb-composition">Checking...</p>
                            </div>
                            <div class="analysis-item">
                                <small>Balance</small>
                                <p id="fb-balance">Checking...</p>
                            </div>
                        </div>

                        <div class="feedback-section">
                            <h4><ion-icon name="thumbs-up-outline"></ion-icon> Strengths</h4>
                            <p id="fb-strengths">Great start with the composition.</p>
                        </div>

                        <div class="feedback-section highlight">
                            <h4><ion-icon name="bulb-outline"></ion-icon> Focus On This</h4>
                            <p id="fb-improvement">Try to balance the negative space.</p>
                        </div>

                        <div class="micro-lesson glass-card inner">
                            <h4 id="lesson-title">Micro-Lesson: Rule of Thirds</h4>
                            <p id="lesson-explanation">definition...</p>
                            <div class="lesson-apply">
                                <strong>Try this:</strong> <span id="lesson-application">...</span>
                            </div>
                        </div>

                        <div class="next-step-container">
                            <button class="btn btn-primary full-width" id="btn-next-step">
                                What should I do next?
                            </button>
                        </div>

                        <div id="next-step-reveal" class="hidden glass-card inner highlight-green">
                            <h4><ion-icon name="footsteps-outline"></ion-icon> Next Step (5-10 min)</h4>
                            <p id="next-step-action">Action...</p>
                            <small id="next-step-reason">Because...</small>
                            <p class="encouragement" id="fb-encouragement">You got this!</p>
                        </div>

                        <div class="session-controls" style="margin-top: 2rem;">
                            <button class="btn btn-outline full-width" id="btn-finish-session">
                                <ion-icon name="stop-circle-outline"></ion-icon> End Session & Reflect
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- History Strip -->
            <div id="history-container" class="glass-card mt-4 hidden">
                <div class="history-header">
                    <h4>Session History</h4>
                    <button id="btn-compare" class="btn btn-sm btn-outline hidden">
                        <ion-icon name="git-compare-outline"></ion-icon> Compare Start vs Now
                    </button>
                </div>
                <div class="history-strip" id="history-strip">
                    <!-- Thumbnails injected here -->
                </div>
            </div>

            <!-- Compare Modal -->
            <div id="compare-modal" class="modal hidden">
                <div class="modal-content glass-card">
                    <span class="close-modal">&times;</span>
                    <h2>Progress Comparison</h2>
                    <div class="compare-grid">
                        <div class="compare-item">
                            <h4>First Sketch</h4>
                            <img id="img-first" src="" alt="First">
                        </div>
                        <div class="compare-item">
                            <h4>Latest Work</h4>
                            <img id="img-latest" src="" alt="Latest">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- View 3: Reflection -->
        <section id="view-reflection" class="view hidden">
            <div class="reflection-card glass-card fade-in">
                <ion-icon name="trophy-outline" class="icon-large"></ion-icon>
                <h2>Session Complete!</h2>
                <p>Great work today. Creating art is a journey.</p>

                <div class="reflection-summary">
                    <div class="summary-item">
                        <label>Practiced Principle</label>
                        <h4 id="ref-principle">...</h4>
                    </div>
                    <div class="summary-item">
                        <label>Improvement Achieved</label>
                        <h4 id="ref-improvement">...</h4>
                    </div>
                    <div class="summary-item">
                        <label>Next Practice</label>
                        <h4 id="ref-practice">...</h4>
                    </div>
                </div>

                <div class="action-buttons">
                    <button class="btn btn-primary" onclick="location.reload()">Start New Session</button>
                </div>
            </div>
        </section>

    </main>

    <footer class="glass-card" style="margin: 2rem auto; max-width: 600px; text-align: center; padding: 1rem; font-size: 0.8rem; opacity: 0.7;">
        <p>Canvas Coach guides your creativity — it never creates the art for you.</p>
    </footer>

    <script src="assets/js/app.js" defer></script>
</body>

</html>