<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

setJsonHeaders();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
    exit;
}

if (!isset($_FILES['artwork']) || !isset($_POST['session_id'])) {
    http_response_code(400);
    echo json_encode(["message" => "No file or session_id uploaded"]);
    exit;
}

$sessionId = $_POST['session_id'];
$file = $_FILES['artwork'];

// Basic Validation
$allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
if (!in_array($file['type'], $allowedTypes)) {
    http_response_code(400);
    echo json_encode(["message" => "Invalid file type. Only JPG, PNG, WEBP allowed."]);
    exit;
}

if ($file['size'] > MAX_FILE_SIZE) {
    http_response_code(400);
    echo json_encode(["message" => "File too large. Max 5MB."]);
    exit;
}

// Generate unique filename
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = uniqid('art_', true) . '.' . $ext;
$targetPath = UPLOAD_DIR . $filename;

// Move file
if (move_uploaded_file($file['tmp_name'], $targetPath)) {
    // Save to DB
    $database = new Database();
    $db = $database->getConnection();

    try {
        $query = "INSERT INTO artworks (session_id, file_path) VALUES (:session_id, :file_path)";
        $stmt = $db->prepare($query);
        $relativePath = 'uploads/' . $filename;
        $stmt->bindParam(":session_id", $sessionId);
        $stmt->bindParam(":file_path", $relativePath);
        $stmt->execute();
        $artworkId = $db->lastInsertId();

        echo json_encode([
            "message" => "Upload successful",
            "artwork_id" => $artworkId,
            "url" => BASE_URL . '/' . $relativePath
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["message" => "Database error: " . $e->getMessage()]);
    }
} else {
    http_response_code(500);
    echo json_encode(["message" => "Failed to move uploaded file."]);
}
