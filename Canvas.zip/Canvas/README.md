# 🎨 Canvas Coach - AI Art Mentor

**Unlock your inner artist.** Canvas Coach is a supportive, AI-powered mentor designed specifically for beginners. It guides you through the creative process, provides constructive visual feedback, and teaches art fundamentals—without ever generating the art for you.

---

## 🌟 Key Features

### 🧠 Smart & Supportive Coaching
- **Visual Analysis**: Instantly identifies your subject, focal point, and composition.
- **Micro-Lessons**: Contextual learning moments (e.g., "Rule of Thirds") triggered by *your* specific artwork.
- **Growth Mindset**: Feedback is always positive, encouraging, and grade-free. "Not yet" instead of "Bad".

### 🚀 Step-by-Step Guidance
- **Creation Roadmap**: Breaking down complex subjects (Portraits, Landscapes) into simple, manageable steps.
- **"What Next?" Engine**: Prevents beginner paralysis by suggesting *one* small, 5-10 minute action at a time.

### 🛡️ Ethical & Transparent
- **100% Human Made**: The AI never generates images. It only guides.
- **Privacy First**: You own your artwork.
- **Transparency**: Clear notices that you are interacting with an AI guide.

---

## ⚙️ Installation & Setup

This project is built for a standard **AMP** stack (Apache, MySQL, PHP). We recommend **XAMPP** for local development on Windows.

### 1. Prerequisites
- **XAMPP** (or WAMP/MAMP) installed.
- **Google Gemini API Key** (Free tier available).

### 2. Database Setup
1. Open **phpMyAdmin** (`http://localhost/phpmyadmin`).
2. Create a new database named `canvas_coach`.
3. Import the schema file located at: `db/schema.sql`.

### 3. Project Configuration
1. Move the `Canvas` folder to your `htdocs` directory (e.g., `C:\xampp\htdocs\Canvas`).
2. Open `config/config.php`.
3. **CRITICAL STEP**: Paste your Google Gemini API Key into the `GEMINI_API_KEY` constant.

```php
// config/config.php
define('GEMINI_API_KEY', 'your_actual_api_key_here');
```

---

## 🤖 IMPORTANT: API Model Selection

We have rigorously tested multiple versions of the Gemini API to find the most stable and free-tier compatible model for this application.

**✅ Recommended Model:** `gemini-flash-latest`

Why?
- **Availability**: During development, newer experimental models like `gemini-2.0` or standard `gemini-1.5-flash` occasionally returned `404 Not Found` or 429 Rate Limit errors on the free tier.
- **Stability**: `gemini-flash-latest` provided the most consistent JSON responses and uptime during our testing.
- **Cost**: It is optimized for speed and cost-efficiency.

*Note: If you wish to change this in the future, check `api/get_ai_feedback.php` line 111.*

---

## 🛠️ Tech Stack
- **Backend**: PHP 8.0+
- **Frontend**: Vanilla JavaScript (ES6+), HTML5
- **Styling**: CSS3 (Custom "Glassmorphism" Design System)
- **Database**: MySQL / MariaDB
- **AI**: Google Gemini API via cURL

---

## 📜 License
This project is open-source and available for educational purposes. Go create something beautiful!
