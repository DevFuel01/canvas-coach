<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

setJsonHeaders();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->session_id) || !isset($data->reflection)) {
    http_response_code(400);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    $query = "INSERT INTO reflections (session_id, content_json) VALUES (:sid, :json)";
    $stmt = $db->prepare($query);
    $json = json_encode($data->reflection); // Wrap in JSON if it's an object/array
    $stmt->bindParam(":sid", $data->session_id);
    $stmt->bindParam(":json", $json);
    $stmt->execute();

    echo json_encode(["message" => "Reflection saved"]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["message" => $e->getMessage()]);
}
